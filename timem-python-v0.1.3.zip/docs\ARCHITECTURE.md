# TiMEM Python SDK 架构设计

## 概述

TiMEM Python SDK 是一个企业级的 Python 客户端库，用于与 TiMEM Engine API 交互。SDK 采用模块化设计，提供同步和异步两种客户端实现，并集成了连接池、熔断器、性能监控等企业级功能。

## 设计原则

### 1. 第一性原理（First Principles）

- **核心目标**：提供简单、可靠、高性能的 TiMEM API 访问
- **必要组件**：
  - 客户端（同步/异步）
  - 请求处理（重试、超时、错误处理）
  - 企业级增强（连接池、熔断器、监控）

### 2. KISS 原则（Keep It Simple, Stupid）

- **简单接口**：提供直观的 API 调用方法
- **合理默认值**：用户只需提供必要参数
- **渐进式增强**：基础功能开箱即用，高级功能可选启用

### 3. SOLID 原则

#### 单一职责原则（Single Responsibility）
- `TiMEMClient`: 负责 API 调用和业务逻辑
- `ConnectionPool`: 负责连接管理
- `CircuitBreaker`: 负责熔断保护
- `PerformanceMonitor`: 负责性能监控

#### 开闭原则（Open/Closed）
- 通过配置类扩展功能（`ConnectionConfig`, `CircuitBreakerConfig`）
- 支持自定义降级函数

#### 里氏替换原则（Liskov Substitution）
- 同步客户端内部使用异步客户端实现
- 接口保持一致性

#### 接口隔离原则（Interface Segregation）
- 经验学习 API（learn, recall）
- 记忆管理 API（add_memory, search_memory）
- 用户画像 API（compute_profile, get_profile）
- 系统 API（health_check, get_system_status）

#### 依赖倒置原则（Dependency Inversion）
- 通过配置对象注入依赖
- 使用全局管理器模式支持依赖替换

### 4. 高内聚、低耦合

#### 高内聚
- 每个模块功能集中、职责明确
- 相关功能组织在一起

#### 低耦合
- 模块之间通过接口交互
- 增强功能可独立启用/禁用

## 架构图

```mermaid
graph TB
    subgraph "客户端层"
        SyncClient[同步客户端<br/>TiMEMClient]
        AsyncClient[异步客户端<br/>AsyncTiMEMClient]
    end
    
    subgraph "核心功能层"
        ExperienceEngine[经验学习引擎<br/>Learn/Recall]
        MemoryMgmt[记忆管理<br/>Add/Search/Update/Delete]
        UserProfile[用户画像<br/>Compute/Get/Search]
        SystemAPI[系统API<br/>Health/Status]
    end
    
    subgraph "增强功能层"
        ConnectionPool[连接池<br/>ConnectionPool]
        CircuitBreaker[熔断器<br/>CircuitBreaker]
        Monitor[性能监控<br/>PerformanceMonitor]
    end
    
    subgraph "基础设施层"
        HTTPClient[HTTP客户端<br/>httpx.AsyncClient]
        Exceptions[异常处理<br/>TiMEMError/APIError]
        Logger[日志记录<br/>StructuredLogger]
    end
    
    SyncClient --> AsyncClient
    AsyncClient --> ExperienceEngine
    AsyncClient --> MemoryMgmt
    AsyncClient --> UserProfile
    AsyncClient --> SystemAPI
    
    ExperienceEngine --> ConnectionPool
    MemoryMgmt --> ConnectionPool
    UserProfile --> ConnectionPool
    SystemAPI --> ConnectionPool
    
    ConnectionPool --> CircuitBreaker
    ConnectionPool --> Monitor
    
    CircuitBreaker --> HTTPClient
    Monitor --> Logger
    
    HTTPClient --> Exceptions
```

## 模块设计

### 1. 客户端模块

#### `sync_client.py` - 同步客户端
```python
class TiMEMClient:
    """同步客户端（兼容层）"""
    def __init__(self, api_key, base_url, ...):
        # 内部使用异步客户端
        self._async_client = AsyncTiMEMClient(...)
    
    def learn(self, ...):
        # 包装异步调用为同步
        return self._run_async(self._async_client.learn(...))
```

**设计要点**：
- 使用异步客户端实现，避免代码重复
- 提供同步接口满足简单场景需求
- 支持上下文管理器自动管理资源

#### `async_client.py` - 异步客户端
```python
class AsyncTiMEMClient:
    """异步客户端（核心实现）"""
    def __init__(self, api_key, base_url, 
                 enable_connection_pool=True,
                 enable_circuit_breaker=True,
                 enable_monitoring=True, ...):
        # 核心配置
        self.api_key = api_key
        self.base_url = base_url
        
        # 增强功能（延迟初始化）
        self._pool = None
        self._circuit_breaker = None
        self._monitor = None
    
    async def learn(self, domain, ...):
        """经验学习"""
        return await self._make_request("POST", "/api/v1/rules/learn-with-llm", ...)
    
    async def _make_request(self, method, endpoint, ...):
        """统一请求处理"""
        # 使用连接池和熔断器
        if self._pool and self._circuit_breaker:
            return await self._circuit_breaker.call(
                self._pool.make_request, ...
            )
        # 传统方式
        return await self._make_traditional_request(...)
```

**设计要点**：
- 异步优先，充分利用并发能力
- 增强功能可选，默认启用
- 统一请求处理，集中错误处理

### 2. 连接池模块

#### `connection_pool.py` - 连接池管理
```python
@dataclass
class ConnectionConfig:
    """连接池配置"""
    max_connections: int = 20
    max_keepalive_connections: int = 10
    keepalive_timeout: float = 30.0
    ...

class ConnectionPool:
    """连接池实现"""
    def __init__(self, base_url, api_key, config, verify_ssl):
        self._pool = httpx.AsyncClient(
            limits=httpx.Limits(...),
            timeout=httpx.Timeout(...),
            ...
        )
    
    async def make_request(self, method, endpoint, ...):
        """使用连接池发送请求"""
        # 自动重试
        for attempt in range(self.config.retry_attempts):
            try:
                response = await self._pool.request(...)
                return response.json()
            except Exception as e:
                if attempt == self.config.retry_attempts - 1:
                    raise
                await asyncio.sleep(self.config.retry_delay)
    
    async def _perform_health_check(self):
        """定期健康检查"""
        ...
```

**设计要点**：
- 连接复用提升性能
- 自动健康检查确保连接可用
- 支持配置化的重试策略

### 3. 熔断器模块

#### `circuit_breaker.py` - 熔断器
```python
class CircuitState(Enum):
    CLOSED = "closed"      # 正常状态
    OPEN = "open"          # 熔断状态
    HALF_OPEN = "half_open"  # 半开状态

@dataclass
class CircuitBreakerConfig:
    failure_threshold: int = 5
    recovery_timeout: float = 60.0
    success_threshold: int = 3
    ...

class CircuitBreaker:
    """熔断器实现"""
    def __init__(self, name, config, fallback_func):
        self.state = CircuitState.CLOSED
        self.failure_count = 0
        ...
    
    async def call(self, func, *args, **kwargs):
        """执行函数调用，带熔断保护"""
        if self.state == CircuitState.OPEN:
            if not self._should_attempt_reset():
                # 调用降级函数
                return await self._call_fallback(...)
            # 尝试半开状态
            self.state = CircuitState.HALF_OPEN
        
        try:
            result = await func(*args, **kwargs)
            self._on_success()
            return result
        except Exception as e:
            self._on_failure()
            raise
```

**设计要点**：
- 三态状态机（关闭、打开、半开）
- 自动故障检测和恢复
- 支持自定义降级策略

### 4. 监控模块

#### `monitoring.py` - 性能监控
```python
@dataclass
class RequestMetrics:
    """请求指标"""
    request_id: str
    method: str
    endpoint: str
    duration: float
    status_code: int
    success: bool
    ...

class PerformanceMonitor:
    """性能监控器"""
    def __init__(self, name):
        self.metrics_collector = MetricsCollector()
        self.logger = StructuredLogger(...)
    
    def record_request(self, method, endpoint, duration, ...):
        """记录请求并检查告警"""
        self.metrics_collector.record_request(...)
        
        # 检查告警条件
        if duration > self.slow_request_threshold:
            self._trigger_alert("slow_request", ...)
```

**设计要点**：
- 结构化日志记录
- 自动性能指标收集
- 可配置的告警阈值

### 5. 异常处理模块

#### `exceptions.py` - 异常定义
```python
class TiMEMError(Exception):
    """基础异常"""
    pass

class AuthenticationError(TiMEMError):
    """认证失败"""
    pass

class APIError(TiMEMError):
    """API错误"""
    def __init__(self, message, status_code=None):
        super().__init__(message)
        self.status_code = status_code
```

**设计要点**：
- 异常层次化设计
- 携带上下文信息
- 便于错误诊断

## 数据流

### 请求流程

```mermaid
sequenceDiagram
    participant User
    participant Client as TiMEMClient
    participant Pool as ConnectionPool
    participant Breaker as CircuitBreaker
    participant Monitor as PerformanceMonitor
    participant API as TiMEM Engine

    User->>Client: learn(domain="aicv")
    Client->>Monitor: 开始监控
    Client->>Breaker: call(pool.make_request)
    
    alt 熔断器打开
        Breaker->>Client: 返回降级结果
        Client->>User: 返回降级响应
    else 熔断器关闭/半开
        Breaker->>Pool: make_request()
        
        loop 重试机制
            Pool->>API: HTTP POST /api/v1/rules/learn-with-llm
            API->>Pool: Response
            
            alt 请求成功
                Pool->>Breaker: 返回结果
                Breaker->>Client: 返回结果
                Breaker->>Breaker: _on_success()
            else 请求失败
                Pool->>Pool: 等待重试
            end
        end
        
        Client->>Monitor: 记录请求指标
        Monitor->>Monitor: 检查告警条件
        Client->>User: 返回结果
    end
```

### 初始化流程

```mermaid
sequenceDiagram
    participant User
    participant Client as AsyncTiMEMClient
    participant Pool as ConnectionPool
    participant Breaker as CircuitBreaker
    participant Monitor as PerformanceMonitor

    User->>Client: AsyncTiMEMClient(api_key, ...)
    Client->>Client: __init__()
    
    User->>Client: async with client
    Client->>Client: __aenter__()
    Client->>Client: _initialize_enhanced_features()
    
    alt 启用连接池
        Client->>Pool: get_connection_pool()
        Pool->>Pool: initialize()
        Pool->>Pool: _create_pool()
        Pool->>Pool: _start_health_check()
        Pool-->>Client: pool
    end
    
    alt 启用熔断器
        Client->>Breaker: get_circuit_breaker()
        Breaker-->>Client: breaker
    end
    
    alt 启用监控
        Client->>Monitor: get_global_monitor()
        Monitor-->>Client: monitor
    end
    
    Client-->>User: client (ready)
```

## 配置管理

### 配置层次

```python
# 1. 客户端配置
client = AsyncTiMEMClient(
    api_key="...",
    base_url="...",
    timeout=60.0,
    max_retries=3,
    enable_connection_pool=True,
    enable_circuit_breaker=True,
    enable_monitoring=True
)

# 2. 连接池配置
connection_config = ConnectionConfig(
    max_connections=20,
    max_keepalive_connections=10,
    retry_attempts=3
)

# 3. 熔断器配置
circuit_breaker_config = CircuitBreakerConfig(
    failure_threshold=5,
    recovery_timeout=60.0,
    success_threshold=3
)
```

### 配置优先级

1. 显式传入的配置对象
2. 客户端初始化参数
3. 默认值

## 性能优化

### 1. 连接复用
- 使用 `httpx.AsyncClient` 的连接池
- 配置合理的 keepalive 参数
- 自动清理空闲连接

### 2. 并发处理
- 异步 I/O 避免阻塞
- 批量操作并发执行
- `asyncio.gather` 等待多个任务

### 3. 请求优化
- 自动重试机制
- 请求超时控制
- 熔断器快速失败

### 4. 资源管理
- 上下文管理器自动清理
- 连接池定期健康检查
- 监控指标限制历史记录数量

## 可扩展性

### 1. 自定义降级策略
```python
async def custom_fallback(*args, **kwargs):
    return {"fallback": True, "data": {}}

client = AsyncTiMEMClient(
    api_key="...",
    circuit_breaker_config=CircuitBreakerConfig(
        fallback_func=custom_fallback
    )
)
```

### 2. 自定义监控告警
```python
def alert_handler(alert_type, data):
    print(f"Alert: {alert_type}, {data}")

monitor = get_global_monitor()
monitor.add_alert_callback(alert_handler)
```

### 3. 扩展新的 API
```python
class ExtendedClient(AsyncTiMEMClient):
    async def custom_api(self, ...):
        return await self._make_request("POST", "/api/v1/custom", ...)
```

## 测试策略

### 1. 单元测试
- 测试每个模块的核心功能
- 使用 mock 隔离依赖
- 覆盖正常和异常场景

### 2. 集成测试
- 测试客户端与 API 交互
- 测试增强功能协同工作
- 使用测试服务器

### 3. 性能测试
- 并发请求压力测试
- 连接池性能测试
- 熔断器触发测试

## 最佳实践

### 1. 使用异步客户端
```python
async with AsyncTiMEMClient(api_key="...") as client:
    result = await client.learn(domain="aicv")
```

### 2. 启用增强功能（生产环境）
```python
client = AsyncTiMEMClient(
    api_key="...",
    enable_connection_pool=True,
    enable_circuit_breaker=True,
    enable_monitoring=True
)
```

### 3. 使用批量操作
```python
# 并发学习多个领域
results = await client.batch_learn(
    domains=["aicv", "education", "consulting"]
)

# 并发添加记忆
results = await client.batch_add_memories(memories)
```

### 4. 错误处理
```python
from timem import TiMEMError, AuthenticationError, APIError

try:
    result = await client.learn(domain="aicv")
except AuthenticationError:
    # 处理认证错误
except APIError as e:
    # 处理API错误
    print(f"API错误 {e.status_code}: {e}")
except TiMEMError as e:
    # 处理其他TiMEM错误
```

## 总结

TiMEM Python SDK 采用模块化、可扩展的架构设计，遵循软件工程最佳实践：

1. **简洁性**：提供直观的 API，默认配置合理
2. **可靠性**：连接池、熔断器、重试机制保证服务稳定
3. **高性能**：异步 I/O、连接复用、并发处理提升效率
4. **可观测性**：结构化日志、性能监控、健康检查
5. **可扩展性**：模块化设计，易于定制和扩展

这个架构设计支持从简单脚本到企业级应用的各种使用场景。

