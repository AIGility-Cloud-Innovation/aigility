# TiMEM SDK v0.1.3 快速开始指南

## 🚀 快速安装

### 1. 卸载旧版本（如果已安装）

```bash
pip uninstall timem-python -y
pip cache purge
```

### 2. 安装 v0.1.3

```bash
pip install timem_python-0.1.3-py3-none-any.whl
```

### 3. 验证安装

```bash
python -c "import timem; print(timem.__version__)"
# 输出: 0.1.3
```

---

## 📖 5分钟快速上手

### 最简单的例子

```python
from timem import TiMEMClient

# 1. 创建客户端
client = TiMEMClient(
    api_key="timem_your_api_key_here",
    base_url="http://localhost:8001"
)

# 2. 健康检查
health = client.health_check()
print(f"状态: {health['status']}")

# 3. 添加记忆
memory = client.add_memory(
    user_id=12345,
    domain="test",
    content={"action": "test"},
    layer_type="L1"
)
print(f"记忆ID: {memory['data']['id']}")

# 4. 关闭客户端
client.close()
```

### 使用上下文管理器（推荐）

```python
from timem import TiMEMClient

with TiMEMClient(api_key="...", base_url="...") as client:
    # 自动管理资源
    result = client.learn(domain="aicv")
    print(f"生成规则: {result['data']['generated_rule_count']}")
# 自动调用 close()
```

---

## 🎯 核心功能示例

### 1. 经验学习（Learn）

从反馈案例中学习生成经验规则：

```python
with TiMEMClient(api_key="...", base_url="...") as client:
    # 提供反馈案例并学习
    result = client.learn(
        domain="aicv",
        feedback_cases=[
            {
                "case_id": "case_001",
                "user_id": 12345,
                "domain": "aicv",
                "context": {"job_title": "Python工程师"},
                "suggestion": "建议添加项目成果",
                "suggestion_type": "项目经验优化",
                "feedback_action": "adopt",
                "feedback_score": 5.0
            }
        ],
        min_case_count=2,
        strategy="adaptive",
        user_id="user_123"  # v0.1.3 新增：用于监控
    )
    
    print(f"生成规则数: {result['data']['generated_rule_count']}")
```

### 2. 规则召回（Recall）

根据上下文召回相关经验规则：

```python
with TiMEMClient(api_key="...", base_url="...") as client:
    rules = client.recall(
        context={
            "job_title": "Python开发工程师",
            "issue_type": "项目经验",
            "section": "工作经历"
        },
        domain="aicv",
        top_k=5,
        min_confidence=0.5,
        user_id="user_123"  # v0.1.3 新增：用于监控
    )
    
    for rule in rules['data']['rules']:
        print(f"规则: {rule['rule_title']}")
        print(f"  置信度: {rule['confidence_score']:.2f}")
```

### 3. 记忆管理

```python
with TiMEMClient(api_key="...", base_url="...") as client:
    # 添加记忆
    memory = client.add_memory(
        user_id=12345,
        domain="aicv",
        content={"type": "resume_view", "action": "view_suggestion"},
        layer_type="L1",
        tags=["resume", "suggestion"],
        keywords=["Python", "项目经验"]
    )
    
    # 搜索记忆
    results = client.search_memory(
        user_id=12345,
        domain="aicv",
        tags=["resume"],
        limit=10
    )
    
    print(f"找到 {results['data']['total']} 条记忆")
```

### 4. 用户画像

```python
with TiMEMClient(api_key="...", base_url="...") as client:
    # 计算用户画像
    profile = client.compute_profile(
        user_id=12345,
        domain="aicv"
    )
    
    # 获取用户画像
    user_profile = client.get_profile(
        user_id=12345,
        domain="aicv"
    )
```

---

## ⚡ 异步客户端（高性能）

### 基础使用

```python
import asyncio
from timem import AsyncTiMEMClient

async def main():
    async with AsyncTiMEMClient(api_key="...", base_url="...") as client:
        # 异步调用
        result = await client.learn(domain="aicv", user_id="user_123")
        rules = await client.recall(context={...}, user_id="user_123")

asyncio.run(main())
```

### 并发操作

```python
async def main():
    async with AsyncTiMEMClient(api_key="...", base_url="...") as client:
        # 并发添加多个记忆
        tasks = [
            client.add_memory(user_id=i, domain="test", content={...})
            for i in range(10)
        ]
        
        results = await asyncio.gather(*tasks)
        print(f"成功添加 {len(results)} 条记忆")

asyncio.run(main())
```

### 批量操作

```python
async def main():
    async with AsyncTiMEMClient(api_key="...", base_url="...") as client:
        # 批量学习多个领域
        results = await client.batch_learn(
            domains=["aicv", "education", "consulting"],
            strategy="adaptive"
        )
        
        # 批量添加记忆
        memories = [
            {"user_id": i, "domain": "test", "content": {...}}
            for i in range(100)
        ]
        results = await client.batch_add_memories(memories)

asyncio.run(main())
```

---

## 🔧 企业级功能

### 启用增强功能

```python
from timem import AsyncTiMEMClient

async with AsyncTiMEMClient(
    api_key="...",
    base_url="...",
    # 企业级功能（默认启用）
    enable_connection_pool=True,      # 连接池
    enable_circuit_breaker=True,      # 熔断器
    enable_monitoring=True            # 性能监控
) as client:
    # 执行操作
    result = await client.learn(domain="aicv")
    
    # 查看统计信息
    stats = client.get_client_stats()
    print(f"总请求: {stats['client_stats']['total_requests']}")
    print(f"成功率: {stats['connection_pool']['success_rate']:.2%}")
```

### 自定义配置

```python
from timem import AsyncTiMEMClient, ConnectionConfig, CircuitBreakerConfig

# 自定义连接池配置
conn_config = ConnectionConfig(
    max_connections=50,
    max_keepalive_connections=20,
    retry_attempts=5
)

# 自定义熔断器配置
breaker_config = CircuitBreakerConfig(
    failure_threshold=10,
    recovery_timeout=30.0
)

async with AsyncTiMEMClient(
    api_key="...",
    base_url="...",
    connection_config=conn_config,
    circuit_breaker_config=breaker_config
) as client:
    # 使用自定义配置
    pass
```

---

## 🎓 完整示例

### 示例1: 基础功能演示

运行完整的基础功能示例：

```bash
python examples/basic_usage.py
```

包含内容：
- ✅ 经验学习和规则召回
- ✅ 记忆管理（增删改查）
- ✅ 用户画像计算
- ✅ 批量操作
- ✅ 健康检查

### 示例2: 异步高性能演示

运行异步客户端示例：

```bash
python examples/async_usage.py
```

包含内容：
- ✅ 基础异步操作
- ✅ 并发操作演示
- ✅ 批量操作优化
- ✅ 便捷函数使用
- ✅ 增强功能展示

### 示例3: 快速验证

运行 v0.1.3 验证脚本：

```bash
python test_quick_v013.py
```

验证内容：
- ✅ 版本检查
- ✅ 同步客户端功能
- ✅ user_id 参数支持
- ✅ 记忆管理
- ✅ 客户端统计
- ✅ 资源清理

---

## 📝 v0.1.3 新特性

### 1. 统一支持 user_id 监控参数

所有主要方法现在都支持 `user_id` 参数用于性能监控：

```python
# v0.1.2（不支持）
result = client.learn(domain="aicv")
rules = client.recall(context={...}, domain="aicv")

# v0.1.3（推荐）
result = client.learn(domain="aicv", user_id="user_123")
rules = client.recall(context={...}, user_id="user_123")
```

### 2. 改进的资源管理

更可靠的资源释放机制：

```python
# 推荐使用上下文管理器
with TiMEMClient(api_key="...") as client:
    # 自动管理资源
    pass
# 自动调用 close()，释放所有资源
```

### 3. 完整的文档和示例

- ✅ 架构设计文档（ARCHITECTURE.md）
- ✅ 详细的使用示例（examples/）
- ✅ 快速验证脚本（test_quick_v013.py）

---

## ⚠️ 常见问题

### Q1: 如何确认已安装 v0.1.3？

```bash
python -c "import timem; print(timem.__version__)"
# 应该显示: 0.1.3
```

### Q2: user_id 参数是必需的吗？

不是必需的，但建议提供以便进行性能监控和问题诊断：

```python
# 不提供 user_id（仍可正常工作）
result = client.learn(domain="aicv")

# 提供 user_id（推荐，便于监控）
result = client.learn(domain="aicv", user_id="user_123")
```

### Q3: 如何启用/禁用增强功能？

```python
# 禁用所有增强功能（最简模式）
client = TiMEMClient(
    api_key="...",
    enable_connection_pool=False,
    enable_circuit_breaker=False,
    enable_monitoring=False
)

# 启用所有增强功能（推荐生产环境）
client = TiMEMClient(
    api_key="...",
    enable_connection_pool=True,
    enable_circuit_breaker=True,
    enable_monitoring=True
)
```

### Q4: 同步客户端 vs 异步客户端？

- **同步客户端** (`TiMEMClient`)：适合简单脚本、单线程场景
- **异步客户端** (`AsyncTiMEMClient`)：适合高并发、批量操作、Web服务

```python
# 同步 - 简单场景
from timem import TiMEMClient
with TiMEMClient(api_key="...") as client:
    result = client.learn(domain="aicv")

# 异步 - 高性能场景
from timem import AsyncTiMEMClient
async with AsyncTiMEMClient(api_key="...") as client:
    result = await client.learn(domain="aicv")
```

---

## 📚 更多资源

- **README.md** - 完整文档
- **ARCHITECTURE.md** - 架构设计
- **CHANGELOG_v0.1.3.md** - 版本变更说明
- **examples/** - 完整示例代码

---

## 🎉 开始使用

现在您已经了解了 TiMEM SDK v0.1.3 的基础用法，可以：

1. ✅ 运行快速验证脚本：`python test_quick_v013.py`
2. ✅ 查看完整示例：`python examples/basic_usage.py`
3. ✅ 阅读架构文档：`ARCHITECTURE.md`
4. ✅ 开始在您的项目中使用 TiMEM SDK

---

**发布日期**: 2025-10-23  
**版本**: v0.1.3  
**状态**: ✅ 稳定版本

祝您使用愉快！🚀

