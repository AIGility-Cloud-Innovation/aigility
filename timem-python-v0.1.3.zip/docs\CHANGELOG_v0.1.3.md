# TiMEM Python SDK v0.1.3 - 重构版本发布

## 🎉 版本概述

v0.1.3 是一个重要的重构版本，修复了多个关键 bug，改进了代码结构，并新增了完整的文档和示例。

**发布日期**: 2025-10-23  
**版本号**: v0.1.3  
**状态**: ✅ 稳定版本

---

## 🔧 Bug 修复

### 1. 修复异步客户端的未定义变量问题

**问题描述**:
在 `async_client.py` 中，`learn()` 和 `recall()` 方法使用了未定义的 `user_id` 变量，导致调用时抛出 `NameError`。

```python
# ❌ 错误代码（v0.1.2）
async def learn(self, domain, ...):
    ...
    return await self._make_request(..., user_id=user_id, domain=domain)
    # user_id 未定义！
```

**修复方案**:
```python
# ✅ 修复代码（v0.1.3）
async def learn(self, domain, ..., user_id: Optional[str] = None):
    ...
    return await self._make_request(..., user_id=user_id, domain=domain)
```

**影响范围**:
- `learn()` 方法（第 378 行）
- `recall()` 方法（第 409 行）

### 2. 修复初始化时的配置引用问题

**问题描述**:
在初始化增强功能时，直接引用了未保存的配置对象，导致 `NameError`。

```python
# ❌ 错误代码（v0.1.2）
async def _initialize_enhanced_features(self):
    self._pool = await get_connection_pool(
        config=connection_config,  # 未定义！
        verify_ssl=self.verify_ssl  # self.verify_ssl 未保存！
    )
```

**修复方案**:
```python
# ✅ 修复代码（v0.1.3）
def __init__(self, ..., connection_config, circuit_breaker_config):
    ...
    self.verify_ssl = verify_ssl
    # 保存配置供后续使用
    self._connection_config = connection_config
    self._circuit_breaker_config = circuit_breaker_config

async def _initialize_enhanced_features(self):
    self._pool = await get_connection_pool(
        config=self._connection_config,
        verify_ssl=self.verify_ssl
    )
```

### 3. 改进资源释放逻辑

**问题描述**:
`close()` 方法中的资源释放逻辑不够完善。

**修复方案**:
```python
# ✅ 改进的资源释放（v0.1.3）
async def close(self):
    """Close the async HTTP client and release all resources."""
    # 关闭连接池
    if self._pool:
        await self._pool.close()
        self._pool = None
    
    # 关闭httpx客户端
    if hasattr(self, 'client') and self.client is not None:
        await self.client.aclose()
        self.client = None
    
    self.logger.info("TiMEM客户端已关闭")
```

---

## ✨ 新增功能

### 1. 完整的使用示例

新增两个完整的示例文件：

#### `examples/basic_usage.py` - 同步客户端示例
- ✅ 经验学习和规则召回
- ✅ 记忆管理操作
- ✅ 用户画像计算
- ✅ 批量操作
- ✅ 健康检查

#### `examples/async_usage.py` - 异步客户端示例
- ✅ 基础异步操作
- ✅ 并发操作演示
- ✅ 批量操作优化
- ✅ 便捷函数使用
- ✅ 增强功能展示

### 2. 架构设计文档

新增 `ARCHITECTURE.md` 文档，包含：

- ✅ 设计原则（第一性原理、KISS、SOLID）
- ✅ 完整的架构图（Mermaid 格式）
- ✅ 模块设计说明
- ✅ 数据流程图
- ✅ 配置管理
- ✅ 性能优化策略
- ✅ 可扩展性说明
- ✅ 最佳实践

### 3. API 改进

所有客户端方法现在统一支持 `user_id` 参数用于监控：

```python
# 同步客户端
result = client.learn(domain="aicv", user_id="user_123")
rules = client.recall(context={...}, user_id="user_123")

# 异步客户端
result = await client.learn(domain="aicv", user_id="user_123")
rules = await client.recall(context={...}, user_id="user_123")
```

---

## 📊 改进内容

### 1. 代码质量

- ✅ 修复所有已知 bug
- ✅ 统一代码风格
- ✅ 完善类型提示
- ✅ 改进错误处理
- ✅ 增强日志记录

### 2. 文档完善

- ✅ 完整的架构设计文档
- ✅ 详细的使用示例
- ✅ API 参数说明
- ✅ 最佳实践指南

### 3. 用户体验

- ✅ 更清晰的错误消息
- ✅ 更好的默认配置
- ✅ 更完善的示例代码
- ✅ 更详细的日志输出

---

## 🚀 升级指南

### 步骤 1: 卸载旧版本

```bash
pip uninstall timem-python -y
```

### 步骤 2: 安装新版本

```bash
pip install timem_python-0.1.3-py3-none-any.whl
```

### 步骤 3: 验证安装

```bash
python -c "import timem; print(timem.__version__)"
# 应显示: 0.1.3
```

### 步骤 4: 更新代码（如有需要）

大部分代码无需修改，但建议检查以下内容：

#### 1. 如果使用了 `user_id` 监控参数

```python
# v0.1.2（不支持）
result = client.learn(domain="aicv")

# v0.1.3（推荐）
result = client.learn(domain="aicv", user_id="user_123")
```

#### 2. 资源释放

```python
# 推荐使用上下文管理器
with TiMEMClient(api_key="...") as client:
    result = client.learn(domain="aicv")
# 自动调用 close()

# 或异步版本
async with AsyncTiMEMClient(api_key="...") as client:
    result = await client.learn(domain="aicv")
# 自动调用 close()
```

---

## 📝 版本对比

| 版本 | 主要问题 | 状态 |
|------|---------|------|
| v0.1.0 | 同步/异步客户端命名混乱 | ❌ 已废弃 |
| v0.1.1 | API Key 请求头格式错误 | ❌ 已废弃 |
| v0.1.2 | 未定义变量、配置引用错误 | ⚠️ 有Bug |
| v0.1.3 | 所有已知问题已修复 | ✅ **推荐使用** |

---

## 🧪 测试验证

### 快速验证脚本

```python
#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""验证 v0.1.3 是否正常工作"""

from timem import TiMEMClient

def test_v013():
    print("="*70)
    print("  TiMEM SDK v0.1.3 - 快速验证")
    print("="*70)
    
    API_KEY = "timem_your_api_key_here"
    BASE_URL = "http://localhost:8001"
    
    try:
        # 1. 测试同步客户端
        print("\n[1/4] 测试同步客户端...")
        with TiMEMClient(api_key=API_KEY, base_url=BASE_URL) as client:
            result = client.health_check()
            print(f"✓ 健康检查通过: {result.get('status')}")
        
        # 2. 测试学习功能（带 user_id）
        print("\n[2/4] 测试学习功能...")
        with TiMEMClient(api_key=API_KEY, base_url=BASE_URL) as client:
            result = client.learn(
                domain="test",
                min_case_count=1,
                user_id="test_user"  # 新增参数
            )
            print(f"✓ 学习功能正常")
        
        # 3. 测试召回功能（带 user_id）
        print("\n[3/4] 测试召回功能...")
        with TiMEMClient(api_key=API_KEY, base_url=BASE_URL) as client:
            result = client.recall(
                context={"test": "context"},
                domain="test",
                user_id="test_user"  # 新增参数
            )
            print(f"✓ 召回功能正常")
        
        # 4. 测试记忆管理
        print("\n[4/4] 测试记忆管理...")
        with TiMEMClient(api_key=API_KEY, base_url=BASE_URL) as client:
            memory = client.add_memory(
                user_id=99999,
                domain="test",
                content={"type": "v013_test"},
                layer_type="L1"
            )
            print(f"✓ 记忆管理正常")
        
        print("\n" + "="*70)
        print("  ✅ v0.1.3 所有功能正常！")
        print("="*70)
        return True
        
    except Exception as e:
        print(f"\n❌ 测试失败: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    import sys
    sys.exit(0 if test_v013() else 1)
```

---

## 📚 相关文档

- **README.md** - 快速开始指南
- **ARCHITECTURE.md** - 架构设计文档（新增）
- **examples/basic_usage.py** - 同步客户端示例（新增）
- **examples/async_usage.py** - 异步客户端示例（新增）
- **LOCAL_INSTALL_GUIDE.md** - 本地安装指南
- **SIMPLE_USAGE.md** - 简单使用说明

---

## 🔍 故障排查

### 问题 1: 导入错误

**症状**:
```python
ImportError: cannot import name 'TiMEMClient' from 'timem'
```

**解决方案**:
```bash
# 1. 完全卸载旧版本
pip uninstall timem-python -y

# 2. 清理缓存
pip cache purge

# 3. 重新安装
pip install timem_python-0.1.3-py3-none-any.whl

# 4. 验证版本
python -c "import timem; print(timem.__version__)"  # 应显示 0.1.3
```

### 问题 2: user_id 参数错误

**症状**:
```python
TypeError: learn() got an unexpected keyword argument 'user_id'
```

**原因**: 仍在使用旧版本

**解决方案**: 按上述步骤升级到 v0.1.3

### 问题 3: 连接池初始化失败

**症状**:
```
NameError: name 'connection_config' is not defined
```

**原因**: 使用了 v0.1.2 的 bug 版本

**解决方案**: 升级到 v0.1.3

---

## 🎯 下一步计划

### v0.2.0 规划

- [ ] 添加流式响应支持
- [ ] 增加批量操作的进度回调
- [ ] 支持自定义序列化器
- [ ] 添加缓存层
- [ ] 支持 Webhook 回调
- [ ] 完善测试覆盖率

---

## 📞 技术支持

如有问题，请联系：

- **Email**: contact@aigility.com
- **GitHub Issues**: [提交问题](https://github.com/AIGility-Cloud-Innovation/timem-python/issues)
- **文档**: 查看完整文档获取更多帮助

---

## 🙏 致谢

感谢所有用户的反馈和建议，帮助我们不断改进 TiMEM SDK。

---

**发布时间**: 2025-10-23  
**SDK 版本**: v0.1.3  
**状态**: ✅ 稳定版本，推荐升级

---

## 完整变更列表

### Bug 修复
- ✅ 修复 `learn()` 方法中未定义的 `user_id` 变量
- ✅ 修复 `recall()` 方法中未定义的 `user_id` 变量
- ✅ 修复初始化时 `connection_config` 未保存的问题
- ✅ 修复初始化时 `verify_ssl` 未保存的问题
- ✅ 改进 `close()` 方法的资源释放逻辑

### 新增功能
- ✨ 新增 `examples/basic_usage.py` 完整示例
- ✨ 新增 `examples/async_usage.py` 异步示例
- ✨ 新增 `ARCHITECTURE.md` 架构文档
- ✨ 统一支持 `user_id` 监控参数

### 改进
- 📝 完善所有方法的文档字符串
- 📝 改进日志输出信息
- 📝 优化错误消息
- 🎨 统一代码风格

### 版本升级
- 📦 版本号: 0.1.2 → 0.1.3
- 📦 更新 `__init__.py` 中的版本号
- 📦 更新 `setup.py` 中的版本号

